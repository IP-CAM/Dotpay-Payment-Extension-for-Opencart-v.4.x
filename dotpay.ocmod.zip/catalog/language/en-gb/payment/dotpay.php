<?php
// Text
$_['text_title'] = 'Dotpay International B.V.';
$_['text_wallet'] = 'Choose Wallet :';
$_['text_button_find'] = 'Find Wallets';