# DOTpay PAYMENT METHOD FOR OPENCART 4.0.X

SOURCE CODE FOR DOTpay OPENCART PLUGIN LOCATED HERE: https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=37980&filter_download_id=36&sort=date_added

Please follow the Opencart 4.0.x DOTpay Plugin install instructions mentioned here: https://docs.google.com/document/d/1NB8xxm8yXLt2j1oMJSjmA4sAk4cJBayGOksMRC2xPKg/edit?usp=sharing

## *********** HOW TO INSTALL IN OPENCART 4 ***********

1:- Download as zip file

2:- Palace this zip file in root directory of your Opencart 4 project

3:- Right click on the zip file and click on Extract Here option.

   Installation done!!
   
   #### *************** OR ***************
   
 1:- Download as zip file
 
 2:- Go to admin dashboard
 
 3:- Navigation >> Extensions >> Installer
 
 4:-  Upload Zip file 
 
		Done!!
   
  ## ******************************** CONFIGURATION ********************************

 1:- Go to admin dashboard
 
 2:- Navigation >> Extensions 
 
 3:- Choose the extension type (Payments)
 
 4:-  Find DOTpay International B.V. in the Payments list
 
 5:-  Click on Plus(+) icon to install and click on edit(pencil) icon to configration.
 
 6:- fill the form and save.
 
       Configuration DONE!!!
   
   
   
   
